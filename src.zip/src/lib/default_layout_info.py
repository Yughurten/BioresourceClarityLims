''' Layout name, well and container types '''

import os

SERVER_NAME = os.uname()[1]

DEFAULT_LAYOUT_INFO = {"5NMPPL" : ["96 well plate", "1"],
                       "ADPRL" : ["96 well plate", "1"],
                       "CLPRL" : ["384 well plate", "3"],
                       "DFLTL" : ["96 well plate", "1"],
                       "ENDRL" : ["96 well plate", "1"],
                       "FLML" : ["96 well plate", "1"],
                       "PCRL" : ["96 well plate", "1"],
                       "PHWL" : ["96 well plate", "1"],
                       "PLNMNL" : ["96 well plate", "1"],
                       "PLSMPL" : ["96 well plate", "1"],
                       "FNLPLL" : ["Tube", "2"],
                      }

if SERVER_NAME == "clarity.haem.cam.ac.uk":
    DEFAULT_LAYOUT_INFO["qPCRL"] = ["384 Well qPCR KAPA", "55"]
else:
    DEFAULT_LAYOUT_INFO["qPCRL"] = ["384 Well qPCR KAPA", "65"]

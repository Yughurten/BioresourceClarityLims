

ROOT_DATA_PATH = "/opt/gls/clarity/data/"
GROUP_IDS = ["NGS", "CTG"]

''' this script readas a MySQL downlaod and create project and associated
    and container(s) and samples '''

import os
import argparse
from time import gmtime, strftime

from xml.dom.minidom import parseString
#from xlrd import open_workbook

from gls_api_util import glsapiutil
from gls_func_utils import (get_logger,
                            log_cmdline_args,
                            ProcessingError)

class SampleSheetImporter:
    ''' import sample and project data to Clarity LIMS '''
    def __init__(self, logger, gau_interface):
        self.logger = logger
        self.gau_interface = gau_interface
        self.base_uri = "131.111.92.191" + "/api/" + "v2" + "/"
        self.rows = []
        self.columns = {}

    @staticmethod
    def get_today():
        ''' get today date in the form 19_02_2018 '''
        today = strftime("%d_%m_%Y", gmtime())
        return today

    def create_sample_xml(self, sample_name, udfs, process_lims_id,
                          cntr_lims_id, project_date, well_location):
        ''' given a sample name and udfs create the xml for creating a sample '''
        sample_xml = ('<smp:samplecreation xmlns:smp="http://genologics.com/ri/sample"' +
                      'xmlns:udf="http://genologics.com/ri/userdefined">')
        sample_xml += '<name>' + sample_name + '</name>'
        sample_xml += '<date-received>' + project_date + '</date-received>'
        sample_xml += ('<project uri="' + self.base_uri +
                       'projects/' + process_lims_id + '"></project>')
        sample_xml += '<location>'
        sample_xml += ('<container uri="' + self.base_uri +
                       'containers/' + cntr_lims_id + '"></container>')
        sample_xml += '<value>' + well_location + '</value>'
        sample_xml += '</location>'
        ## add the udfs
        for udf_name in udfs:
            sample_xml += '<udf:field name="' + udf_name + '">' + udfs[udf_name] + '</udf:field>'
        sample_xml += '</smp:samplecreation>'

        return sample_xml

    def create_container(self, cntr_type, cntr_name):
        ''' given a container type and name create a container '''
        cntr_lims_id = None

        query_uri = self.base_uri + "containertypes?name=" + cntr_type
        query_xml = self.gau_interface.getResourceByURI(query_uri)
        query_dom = parseString(query_xml)

        nodes = query_dom.getElementsByTagName("container-type")
        if nodes:
            cntr_uri = nodes[0].getAttribute("uri")

            xml = '<?xml version="1.0" encoding="UTF-8"?>'
            xml += '<con:container xmlns:con="http://genologics.com/ri/container">'
            if cntr_name:
                xml += ('<name>' + cntr_name + '</name>')
            else:
                xml += '<name></name>'
            xml += '<type uri="' + cntr_uri + '"/>'
            xml += '</con:container>'

            rsp_xml = self.gau_interface.createObject(xml, self.base_uri + "containers")

            rsp_dom = parseString(rsp_xml)
            nodes = rsp_dom.getElementsByTagName("con:container")
            if nodes:
                cntr_lims_id = nodes[0].getAttribute("limsid")

        return cntr_lims_id

    @staticmethod
    def parse_file(filename):
        ''' parse cvs file and build data structure '''
        fileaname = None
        return True
        #global self.columns
        #global ROWS

        #book = open_workbook(filename, formatting_info=False)
        #worksheet = book.sheet_by_index(-1)

        ## Technically you're not supposed to do this to access the cells, but it's much
        ## easier to manipulate this way than it is to use the accessor functions.
        #cells = worksheet._cell_values

        ### DO WE HAVE THE CORRECT BASIC FORMAT?
        #headerStart = -1
        #headerStop = -1
        #dataStart = -1
        #dataStop = -1

        #rowCount = 0
        #for row in cells:
        #    if headerStart == -1 and row[0] == "<TABLE HEADER>":
        #        headerStart = rowCount
        #    elif headerStop == -1 and row[0] == "</TABLE HEADER>":
        #        headerStop = rowCount
        #    elif dataStart == -1 and row[0] == "<SAMPLE ENTRIES>":
        #        dataStart = rowCount
        #    elif dataStop == -1 and row[0] == "</SAMPLE ENTRIES>":
        #        dataStop = rowCount
        #    rowCount += 1
   #
   #     if headerStop > headerStart and dataStop > dataStart and dataStart > headerStop:

   #         ## make sense of the column headers
   #         cols = cells{headerStart + 1]
   #         for i in range(0, len(cols)):
   #             self.columns{cols[i]] = i
   #
   #         ## store the rows that contain the data of interest
   #         ROWS = cells{dataStart + 1:dataStop]
   #
   #         return True
   #     else:
   #         return False

    def create_project(self, project_name, udfs, project_date):
        ''' given a project name, user defined fields and project date
            create a project entity in the Clarity LIMS '''
        project_lims_id = None

        query_uri = self.base_uri + "projects?name=" + project_name
        query_xml = self.gau_interface.getResourceByURI(query_uri)
        query_dom = parseString(query_xml)

        ## did we get any project nodes?
        nodes = query_dom.getElementsByTagName("project")
        #nodeCount = len(nodes)

        if not nodes:
            ## create a new project
            project_xml = '<?xml version="1.0" encoding="utf-8"?>'
            project_xml += ('<prj:project xmlns:udf="http://genologics.com/ri/userdefined"' +
                            'xmlns:ri="http://genologics.com/ri"' +
                            'xmlns:file="http://genologics.com/ri/file"' +
                            'xmlns:prj="http://genologics.com/ri/project">')
            project_xml += '<name>' + project_name + '</name>'
            project_xml += '<open-date>' + project_date + '</open-date>'
            project_xml += '<researcher uri="' + self.base_uri + 'researchers/1"/>'
            ## add the udfs
            for udf_name in udfs.keys():
                project_xml += ('<udf:field name="' + udf_name + '">' +
                                udfs[udf_name] + '</udf:field>')

            project_xml += '</prj:project>'
            project_xml = project_xml.encode("utf-8")

            ## create this in LIMS
            rsp_xml = self.gau_interface.createObject(project_xml, self.base_uri + "projects")
            try:
                rsp_dom = parseString(rsp_xml)
                nodes = rsp_dom.getElementsByTagName("prj:project")
                if nodes:
                    project_lims_id = nodes[0].getAttribute("limsid")
                    msg = "Created Project: {}  with Name: {}".format(project_lims_id, project_name)
                    self.logger.debug(msg)
                else:
                    self.logger.error("Error creating project")
                    self.logger.debug(rsp_xml)
            except Exception as err:
                msg = "Error creating project" + str(err)
                self.logger.error(msg)
                self.logger.debug(rsp_xml)

        else:
            ## we have a project, return the limsid
            self.logger.debug("Project with name: " + project_name + " already in system")
            project_lims_id = nodes[0].getAttribute("limsid")

        return project_lims_id

    def process_rows(self):
        ''' process the data read from the downlod file '''
        created_projects_cache = {}
        created_containers_cache = {}

        ## let's harvest the UDF names
        udf_names = {}
        for column_name in self.columns:
            if column_name.startswith("UDF/"):
                udf_name = column_name.replace("UDF/", "")
                udf_names[udf_name] = self.columns[column_name]

        batch_sample_xml = []
        batch_sample_xml.append('<?xml version="1.0" encoding="UTF-8"?>')
        batch_sample_xml.append('<smp:details xmlns:smp="http://genologics.com/ri/sample">')

        for row in self.rows:
            sample_name = row[self.columns["Sample/Name"]].strip()
            self.logger.debug(sample_name)

            project_name = row[self.columns["Project/Name"]].strip()

            ## check if the project already exist in LIMS
            if project_name not in created_projects_cache:
                project_lims_id = self.create_project(project_name, {}, self.get_today())
                created_projects_cache[project_name] = project_lims_id
            else:
                project_lims_id = created_projects_cache[project_name]

            ## organize the data elements we need

            ## deal with the container, is it a simple case (Tube),
            ## or complex case (multi-sample container)
            cntainer_type = row[self.columns["Container/Type"]].strip()
            cntr_name = row[self.columns["Container/Name"]].strip()

            if cntainer_type == "Tube" or not cntainer_type:
                cntr_lims_id = self.create_container("Tube", cntr_name)
                well_location = '1:1'
            else:
                if cntr_name not in created_containers_cache:
                    con_uri = self.base_uri + "containers?name=" + cntr_name
                    con_xml = self.gau_interface.getResourceByURI(con_uri)
                    con_dom = parseString(con_xml)
                    nodes = con_dom.getElementsByTagName("container")
                    cntr_count = len(nodes) # how many containers with this name in LIMS

                    if not nodes:
                        cntr_lims_id = self.create_container(cntainer_type, cntr_name)
                        msg = "Creating container: {} lims_id: {}".format(cntr_name, cntr_lims_id)
                        self.logger.debug(msg)
                    elif cntr_count == 1:
                        cntr_lims_id = nodes[0].getAttribute("limsid")
                        msg = "Found container: {} lims_id: {}".format(cntr_name, cntr_lims_id)
                        self.logger.debug(msg)
                    else:
                        err_msg = "More then 1 container named: " + cntr_name
                        self.logger.error(err_msg)
                        raise ProcessingError(err_msg)

                    created_containers_cache[cntr_name] = cntr_lims_id

                else:
                    cntr_lims_id = created_containers_cache[cntr_name]
                well_location = row[self.columns["Sample/Well Location"]].strip()
                print(well_location)

            ## now we have the container sorted, let's get the minimum sample metadata

            ## let's harvest udfs
            udfs = {}
            for udf_name in udf_names:
                val = str(row[udf_names[udf_name]])
                if val:
                    udfs[udf_name] = val

            ## finally create the sample
            sample_xml = self.create_sample_xml(sample_name, udfs, project_lims_id,
                                                cntr_lims_id, self.get_today(), well_location)

            batch_sample_xml.append(sample_xml)

        batch_sample_xml.append('</smp:details>')
        batch_sample_xml = "".join(batch_sample_xml)

        #print(batch_sample_xml

        batch_sample_uri = self.base_uri + "samples/batch/create"
        rsp_xml = self.gau_interface.createObject(batch_sample_xml, batch_sample_uri)
        try:
            rsp_dom = parseString(rsp_xml)
            nodes = rsp_dom.getElementsByTagName("link")
            if nodes:
                self.logger.debugog(str(len(nodes)) + " samples created")
            else:
                err_msg = "Error creating samples"
                self.logger.error(err_msg)
                self.logger.debug(rsp_xml)
        except Exception as err:
            err_msg = "Error creating samples" + str(err)
            self.logger.error(err_msg)
            self.logger.debug(rsp_xml)

def main():
    ''' program main routine: extract program tokens from the cmd line
        arguments passed by Clarity LIMS automation and start the processing '''
    parser = argparse.ArgumentParser()
    parser.add_argument("-h", "--hostname", help="server host name")
    parser.add_argument("-u", "--username", help="username of the current user")
    parser.add_argument("-p", "--password", help="password of the current user")
    parser.add_argument("-f", "--filename", help="data file name")
    parser.add_argument("-g", "--logFilename", help="log file name")
    args = parser.parse_args()

    prog_name = os.path.basename(__file__)
    logger = get_logger(prog_name)

    log_cmdline_args(logger, prog_name, args.hostname, args.username, args.password, args.stepURI)

    gau_interface = glsapiutil()
    gau_interface.setHostname(args.hostname)
    gau_interface.setup(args.username, args.password)

    program_status = None
    try:
        exit_msg = None
        sample_importer = SampleSheetImporter(logger, gau_interface)
        status = sample_importer.parse_file(args.fileName)
        if status is True:
            sample_importer.process_rows()
        else:
            print("The script was unable to parse the file: " + args.filename)
    except ProcessingError as err:
        exit_msg = "Importing samples has failed {}".format(str(err))
        program_status = 1
    except Exception as err:
        exit_msg = "Importing samples has failed {}".format(str(err))
        program_status = 1
    else:
        exit_msg = "Import of samples has completed successfully"
        program_status = 0
    finally:
        print(exit_msg)
        logger.info(exit_msg)

    return program_status

if __name__ == "__main__":
    main()
